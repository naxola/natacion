import { Component } from '@angular/core';
@Component({
    selector: 'profile-box',
	templateUrl: './profile.component.html'
})
export class ProfileComponent  {
		
	constructor() {  
		 
	}
}
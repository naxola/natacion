import { Component } from '@angular/core';
@Component({
    selector: 'social-slider',
	templateUrl: './social-slider.component.html'
})
export class SocialSliderComponent {
		 
	constructor() {
		
	}

	
}
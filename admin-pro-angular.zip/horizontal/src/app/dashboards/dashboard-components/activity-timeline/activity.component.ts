import { Component } from '@angular/core';
@Component({
    selector: 'activity-timeline',
	templateUrl: './activity.component.html'
})
export class ActivityComponent  {
		
	constructor() { 
		
	}
}